<?php
class user_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	function displayrecordsById($id)
	{
	$query=$this->db->query("select * from user where id='".$id."'");
	print_r($query);
	return $query->row();
	}
}