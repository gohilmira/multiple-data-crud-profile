<html>
  <head>
      <title>Creater</title>
      <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap.css" /> -->
      <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" />
      <!-- <link rel="stylesheet" href="<?php //echo base_url(); ?>assets/css/dataTables.bootstrap.css" /> -->
      <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/dataTables.bootstrap5.min.css" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </head>
  <body>
<div class="row">
<div class="col-sm-3">
<div class="card" style="width: 18rem;">
  
  <div class="card-body">
    <h5 class="card-title">Profile</h5>
    <h6 class="card-img-top" align="right"><i class="fa fa-edit"></i></h6>
  </div>
  <img class="card-img-top" src="<?php echo base_url('upload/'.$user->image); ?>" alt="Card image cap">
  <ul class="list-group list-group-flush">
    <li class="list-group-item" style="text-align: center;color: #1885e3;"><?php echo $user->fullname; ?></li>
    <li class="list-group-item" style="text-align: center;"><?php echo $user->prof; ?></li>
    <li class="list-group-item" style="text-align: center;"><?php echo date("M d, Y", strtotime($user->dob)); ?></li>
    <li class="list-group-item" style="text-align: center;"><?php echo $user->address,$user->country; ?></li>
    <li class="list-group-item" style="text-align: center;"><?php echo $user->email; ?></li>
    <li class="list-group-item" style="text-align: center;"><?php echo $user->phone; ?></li>
  </ul>
  <div class="card-body"style="text-align: center;">
    <a href="https://www.facebook.com/" class="card-link"><i class="fa fa-facebook"></i></a>&nbsp;&nbsp;&nbsp;
    <a href="https://twitter.com/i/flow/login" class="card-link"><i class="fa fa-twitter"></i></a>&nbsp;&nbsp;&nbsp;
    <a href="https://www.linkedin.com/" class="card-link"><i class="fa fa-linkedin"></i></a>
  </div>
</div>
  <div class="card" style="width: 18rem;">
 
  <div class="card-body">
    <h5 class="card-title">Education</h5>
  </div>
  <?php 
  $result=$this->db->query("select * from education where user_id='".$user->id."'");
  foreach($result->result() as $re)
  	{
  	?>
  	<ul class="list-group list-group-flush">
    <li class="list-group-item"><?php echo date("M", strtotime($re->e_s_month));  ?>&nbsp;<?php echo $re->e_s_year; ?>&nbsp;&nbsp;&nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i>&nbsp;<?php echo $re->collagename; ?></li>   </ul>
<?php } ?>

  
</div>
  <div class="card" style="width: 18rem;">
  
  <div class="card-body">
    <h5 class="card-title">Work Experience</h5>
  </div>
    <?php 
  $result=$this->db->query("select * from work_exp where user_id='".$user->id."'");
  foreach($result->result() as $re)
  	{
  	?>
  <ul class="list-group list-group-flush">
   <li class="list-group-item"><?php echo date("M", strtotime($re->w_s_month)); ?>&nbsp;<?php echo $re->w_s_year; ?>&nbsp;&nbsp;&nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i>&nbsp;<?php echo $re->com_name; ?></li>
  </ul>
<?php } ?>
</div>
</div>

  
  <div class="col-sm-8">
  	<a href='<?php echo base_url("user_controller/index"); ?>' class='btn btn-primary ' style="margin-left: 1200;">Home</a>
  	
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Skill</h5>
        
           <?php 
  $result=$this->db->query("select * from skill where user_id='".$user->id."'");
  foreach($result->result() as $re)
  	{
  	?>
  <ul class="list-group list-group-flush">
   <li class="list-group-item">
 <h6><?php echo $re->skillname; ?>  &nbsp;</h6><div class="progress">	
  <div class="progress-bar" style="width:<?php echo $re->percentage; ?>%"><?php echo $re->percentage; ?>%</div>
</div>
</li>
    
  </ul>
<?php } ?>
        
      </div>
    </div>


    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Bio</h5>
        <?php 
  $result=$this->db->query("select * from work_platform where user_id='".$user->id."'");
  foreach($result->result() as $re)
  	{
  	?>
        <p class="card-text">
        <div class="row">
    	<div class="col" ><h5 class="card-title"><?php echo $re->platform_title; ?></h5><?php echo $re->pl_des; ?></div>
		</div>
</div>
    </p>       
<?php } ?>
    </div>
   </div>
</div>
</div>

</body>
</html>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.1.1.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.6.0.min.js "></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js "></script>
