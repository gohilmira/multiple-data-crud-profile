<html>
<head>
  <title>Creater</title>
  <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap.css" /> -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" />
  <!-- <link rel="stylesheet" href="<?php //echo base_url(); ?>assets/css/dataTables.bootstrap.css" /> -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/dataTables.bootstrap5.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<style>
  .form {
    display: flex;
    flex-direction: column;
  }
</style>
<body>
  <div class="card form">
    <div class="card-body">
      <h5 class="card-title">General Information</h5>
 <!--  Upload Picture
      <input type="file" name="image" id="image" />
       <br />
   <span id="uploaded_image"></span> -->
      Full Name :
      <input type="text" name="fullname" id="fullname">
      Date Of Birth
      <?php
    $selected_day = date('d'); //current day

    echo '<select id="day" name="day">'."\n";
    for ($i_day = 1; $i_day <= 31; $i_day++) { 
        $selected = ($selected_day == $i_day ? ' selected' : '');
        echo '<option value="'.$i_day.'"'.$selected.'>'.$i_day.'</option>'."\n";
    }
    echo '</select>'."\n";

    $selected_month = date('m'); //current month

    echo '<select id="month" name="month">'."\n";
    for ($i_month = 1; $i_month <= 12; $i_month++) { 
        $selected = ($selected_month == $i_month ? ' selected' : '');
        echo '<option value="'.$i_month.'"'.$selected.'>'. date('F', mktime(0,0,0,$i_month)).'</option>'."\n";
    }
    echo '</select>'."\n";

    $year_start  = 1940;
    $year_end = date('Y'); // current Year
    $user_selected_year = 2022; // user date of birth year

    echo '<select id="year" name="year">'."\n";
    for ($i_year = $year_start; $i_year <= $year_end; $i_year++) {
        $selected = ($user_selected_year == $i_year ? ' selected' : '');
        echo '<option value="'.$i_year.'"'.$selected.'>'.$i_year.'</option>'."\n";
    }
    echo '</select>'."\n";
?>

      Profession:
      <input type="text" name="prof" id="prof"></div>
      <div class="card-body">
        <h4>About</h4>
        Bio
        <input type="textarea" name="bio" id="bio">


        <div class="card-body" id="dynamic_field">
         <h4>Work platforms <button type="button" name="add" id="addplatforms" class="btn btn-success">Add More</button></h4>
         <ul>
            <li>Platform Title
          <input type="text" name="platform_title[]" >
          Platform Description
          <input type="textarea" name="pl_des[]" ></li>
          </ul>      
        </div>


        <div class="card-body">
          <h4>Contact</h4>
          Country: <Select id='country' name="Country">
            <option value="">Select Country</option>
          <?php  
          $result=$this->db->query("select * from country");
                    foreach($result->result() as $re)
                     {
                        ?>
                        
                        <option value="<?php echo $re->name;?>"><?php echo $re->name; ?></option>
                        <?php
                        }
                        ?></Select>
          Address
          <input type="text" name="address" id="address">
          Location
          <input type="text" name="location" id="location">
          phone
          <input type="number" name="phone" id="phone">
          email
          <input type="text" name="email" id="email">
          website
          <input type="text"  name="website" id="website">
        </div> 
        <div class="card-body">
          <h4>social</h4>
          <i class="fa fa-facebook"></i>
          <input type="text" name="facebook" id="facebook">
          <i class="fa fa-linkedin"></i>
          <input type="text" name="linkedin" id="linkedin">
          <i class="fa fa-twitter"></i>
          <input type="text" name="twitter" id="twitter">
          <i class="fa fa-github"></i>
          <input type="text" name="github" id="github">
        </div>
        <div class="card-body" id="dynamic_field3">
          <h4>Skill <button type="button" name="add" id="addskill" class="btn btn-success">Add More</button></h4>
          <h7>Skill Name:</h7><input type="text" name="skillname[]" >
          <h7>Percentage</h7><input type="number" name="percentage[]" >
        </div>
        <div class="card-body" id="dynamic_field1">
          <h4>Education <button type="button" name="add" id="addeducation" class="btn btn-success">Add More</button></h4>
          Enter Your Collage Name:
          <input type="text" name="collagename[]" >
          Starting From
            <select name=e_s_month[]>Select Month</option>
            <option value='01'>January</option>
            <option value='02'>February</option>
            <option value='03'>March</option>
            <option value='04'>April</option>
            <option value='05'>May</option>
            <option value='06'>June</option>
            <option value='07'>July</option>
            <option value='08'>August</option>
            <option value='09'>September</option>
            <option value='10'>October</option>
            <option value='11'>November</option>
            <option value='12'>December</option>
            </select>
            <select  name="e_s_year[]">
              <?php
                $y=(int)date('Y');
                ?>
                <option value="<?php echo $y;?>" selected="true"><?php echo $y;?></option>
                  <?php
                  $y--;
                for(; $y>'1900'; $y--)
                {
              ?>
              <option value="<?php echo $y;?>"><?php echo $y;?></option>
              <?php }?>
            </select>
          
          Ending From
          <select name=e_e_month[] >Select Month</option>
            <option value='01'>January</option>
            <option value='02'>February</option>
            <option value='03'>March</option>
            <option value='04'>April</option>
            <option value='05'>May</option>
            <option value='06'>June</option>
            <option value='07'>July</option>
            <option value='08'>August</option>
            <option value='09'>September</option>
            <option value='10'>October</option>
            <option value='11'>November</option>
            <option value='12'>December</option>
            </select>
            <select  name="e_e_year[]">
              <?php
                $y=(int)date('Y');
                ?>
                <option value="<?php echo $y;?>" selected="true"><?php echo $y;?></option>
                  <?php
                  $y--;
                for(; $y>'1900'; $y--)
                {
              ?>
              <option value="<?php echo $y;?>"><?php echo $y;?></option>
              <?php }?>
            </select>
          Description
          <input type="textarea " name="edu_dec[]" > 
        </div>
        <div class="card-body" id="dynamic_field2"> 
          <h4>Work Experience <button type="button" name="add" id="addworkexp" class="btn btn-success">Add More</button></h4> 
          Company Name:   
          <input type="text" name="com_name[]" >
          Job Title
          <input type="text" name="job_title[]" >
          Location
          <input type="text" name="w_location[]" >
          Starting From
            <select name=w_s_month[]>Select Month</option>
            <option value='01'>January</option>
            <option value='02'>February</option>
            <option value='03'>March</option>
            <option value='04'>April</option>
            <option value='05'>May</option>
            <option value='06'>June</option>
            <option value='07'>July</option>
            <option value='08'>August</option>
            <option value='09'>September</option>
            <option value='10'>October</option>
            <option value='11'>November</option>
            <option value='12'>December</option>
            </select>
            <select  name="w_s_year[]">
              <?php
                $y=(int)date('Y');
                ?>
                <option value="<?php echo $y;?>" selected="true"><?php echo $y;?></option>
                  <?php
                  $y--;
                for(; $y>'1900'; $y--)
                {
              ?>
              <option value="<?php echo $y;?>"><?php echo $y;?></option>
              <?php }?>
            </select>
          
          Ending From
          <select name=w_e_month[] >Select Month</option>
            <option value='01'>January</option>
            <option value='02'>February</option>
            <option value='03'>March</option>
            <option value='04'>April</option>
            <option value='05'>May</option>
            <option value='06'>June</option>
            <option value='07'>July</option>
            <option value='08'>August</option>
            <option value='09'>September</option>
            <option value='10'>October</option>
            <option value='11'>November</option>
            <option value='12'>December</option>
            </select>
            <select  name="w_e_year[]">
              <?php
                $y=(int)date('Y');
                ?>
                <option value="<?php echo $y;?>" selected="true"><?php echo $y;?></option>
                  <?php
                  $y--;
                for(; $y>'1900'; $y--)
                {
              ?>
              <option value="<?php echo $y;?>"><?php echo $y;?></option>
              <?php }?>
            </select>
          Description
          <input type="textarea " name="work_dec[]" >  
          
        </div>
        <button id="save" style="margin-left: 1700;" class="btn btn-primary">Save Changes</button>
      </div>
      <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.1.1.js"></script>
      <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.js"></script>
      <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.6.0.min.js "></script>
      <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js "></script>
      <script type="text/javascript">
        $(document).ready(function(){
           var i=1;  
           $('#addplatforms').click(function(){  
                i++;  
                $('#dynamic_field').append('<ul id="row'+i+'" class="dynamic-added"><li>Platform Title<input type="text" name="platform_title[]" class="name_list" required />Platform Description<input type="text" name="pl_des[]" class="name_list" required /><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></li></ul>');  
           });
            $(document).on('click', '.btn_remove', function(){  
         
                var button_id = $(this).attr("id");   
         
                $('#row'+button_id+'').remove();  
         
           }); 
           var i=1;  
           $('#addeducation').click(function(){  
                i++;  
                $('#dynamic_field1').append('<ul id = "row' + i + '" class= "dynamic-added" > <li>Enter Your Collage Name: <input type="text" name="collagename[]"  class="name_list" required />Starting From<select name=e_s_month[]>Select Month<option value="01">January</option><option value="02">February</option><option value="03">March</option><option value="04">April</option><option value="05">May</option><option value="06">June</option><option value="07">July</option><option value="08">August</option><option value="09">September</option><option value="10">October</option><option value="11">November</option><option value="12">December</option></select><select name="e_s_year[]">             <?php              $y=(int)date('Y');              ?>              <option value="<?php echo $y;?>" selected="true"><?php echo $y;?></option>                <?php                $y--;              for(; $y>'1900'; $y--)              {              ?>              <option value="<?php echo $y;?>"><?php echo $y;?></option>              <?php }?>            </select>Ending From<select name=e_e_month[] >Select Month<option value="01">January</option><option value="02">February</option><option value="03">March</option><option value="04">April</option><option value="05">May</option><option value="06">June</option><option value="07">July</option><option value="08">August</option><option value="09">September</option><option value="10">October</option><option value="11">November</option><option value="12">December</option></select> <select name="e_e_year[]">  <?php                $y=(int)date('Y');                ?>                <option value="<?php echo $y;?>" selected="true"><?php echo $y;?></option>                  <?php                  $y--;                for(; $y>'1900'; $y--)                {              ?>              <option value="<?php echo $y;?>"><?php echo $y;?></option>              <?php }?>            </select>description<input type="textarea" name="edu_dec[]" class="name_list" required /><button type="button" name="remove" id="' + i + '" class="btn btn-danger btn_remove1">X</button></li></ul>');  
           });
            $(document).on('click', '.btn_remove1', function(){  
         
                var button_id = $(this).attr("id");   
         
                $('#row'+button_id+'').remove();  
         
           }); 
            var l=1; 
            $('#addworkexp').click(function(){  
                l++;  
                $('#dynamic_field2').append('<ul id="row'+l+'" class="dynamic-added"><li>Company Name:<input type="text" name="com_name[]" class="name_list" required />Job Title:<input type="text" name="job_title[]" class="name_list" required />Location:<input type="text" name="w_location[]" class="name_list" required /> Starting From<select name=w_s_month[]>Select Month<option value="01">January</option><option value="02">February</option><option value="03">March</option><option value="04">April</option><option value="05">May</option><option value="06">June</option><option value="07">July</option><option value="08">August</option><option value="09">September</option><option value="10">October</option><option value="11">November</option><option value="12">December</option></select><select name="w_s_year[]">             <?php              $y=(int)date('Y');              ?>              <option value="<?php echo $y;?>" selected="true"><?php echo $y;?></option>                <?php                $y--;              for(; $y>'1900'; $y--)              {              ?>              <option value="<?php echo $y;?>"><?php echo $y;?></option>              <?php }?>            </select>Ending From<select name=w_e_month[] >Select Month<option value="01">January</option><option value="02">February</option><option value="03">March</option><option value="04">April</option><option value="05">May</option><option value="06">June</option><option value="07">July</option><option value="08">August</option><option value="09">September</option><option value="10">October</option><option value="11">November</option><option value="12">December</option></select> <select name="w_e_year[]">  <?php                $y=(int)date('Y');                ?>                <option value="<?php echo $y;?>" selected="true"><?php echo $y;?></option>                  <?php                  $y--;                for(; $y>'1900'; $y--)                {              ?>              <option value="<?php echo $y;?>"><?php echo $y;?></option>              <?php }?> Description<input type="textarea" name="work_dec[]" class="name_list" required /><button type="button" name="remove" id="'+l+'" class="btn btn-danger btn_remove2">X</button></li></ul>');  
           });
            $(document).on('click', '.btn_remove2', function(){  
         
                var button_id = $(this).attr("id");   
         
                $('#row'+button_id+'').remove();  
         
           }); 
            var m=1; 
            $('#addskill').click(function(){  
                m++;  
                $('#dynamic_field3').append('<ul id="row'+m+'" class="dynamic-added"><li>Skill Name:<input type="text" name="skillname[]" class="name_list" required />Percentage:<input type="text" name="percentage[]" class="name_list" required /><button type="button" name="remove" id="'+m+'" class="btn btn-danger btn_remove3">X</button></li></ul>');  
           });
            $(document).on('click', '.btn_remove3', function(){  
         
                var button_id = $(this).attr("id");   
         
                $('#row'+button_id+'').remove();  
         
           }); 

        $("#save").on("click", function(e){
          $.post({
            dataType:'json',
            url: "<?php echo base_url('user_controller/save'); ?>"
            , data: { 
                fullname: $("#fullname").val()
              , day: $("#day").val()
              , month: $("#month").val()
              , year: $("#year").val()
              , prof: $("#prof").val()
              , bio: $("#bio").val()
              , platform_title: $("input[name='platform_title[]']").get().map(x => x.value)
              , pl_des: $("input[name='pl_des[]']").get().map(x => x.value)
              , country: $("#country").val()
              , address: $("#address").val()
              , location: $("#location").val()
              , phone: $("#phone").val()
              , email: $("#email").val()
              , website: $("#website").val()
              , facebook: $("#facebook").val()
              , linkedin: $("#linkedin").val()
              , twitter: $("#twitter").val()
              , github: $("#github").val()
              , skillname: $("input[name='skillname[]']").get().map(x => x.value)
              , percentage: $("input[name='percentage[]']").get().map(x => x.value)
              , collagename: $("input[name='collagename[]']").get().map(x => x.value)
              , e_s_month: $("[name='e_s_month[]' ]").get().map(x => x.value)
              , e_s_year: $("[name='e_s_year[]']").get().map(x => x.value)
              , e_e_month: $("[name='e_e_month[]']").get().map(x => x.value)
              , e_e_year: $("[name='e_e_year[]']").get().map(x => x.value)
              , edu_dec: $("input[name='edu_dec[]']").get().map(x => x.value)
              , com_name: $("input[name='com_name[]']").get().map(x => x.value)
              , job_title: $("input[name='job_title[]']").get().map(x => x.value)
              , w_location: $("input[name='w_location[]']").get().map(x => x.value)
              , w_s_month: $("[name='w_s_month[]' ]").get().map(x => x.value)
              , w_s_year: $("[name='w_s_year[]']").get().map(x => x.value)
              , w_e_month: $("[name='w_e_month[]']").get().map(x => x.value)
              , w_e_year: $("[name='w_e_year[]']").get().map(x => x.value)
              , work_dec: $("input[name='work_dec[]']").get().map(x => x.value)
              , id: $("#id").val()
            }
          }).then(function(res){
            if(res === true){
              alert("Saved");
              $("#fullname, #day, #month, #year, #prof, #bio, #platform_title, #pl_des, #country, #address, #location, #phone, #email, #website, #facebook, #linkedin, #twitter, #github, #php, #wordpress, #javascript, #jquery, #collagename, #e_s_month, #e_s_year, #e_e_month, #e_e_year, #edu_dec, #com_name, #job_title, #w_location, #w_starting_date, #w_ending_date, #work_dec").val('');
              dt.ajax.reload();
            } else {
              alert(res);
            }
          });
        });

       function month(){
        let id = e.currentTarget.options[e.currentTarget.selectedIndex].value;
        $.post({
          dataType:'json',
          url: "<?php echo base_url('Test/get_month'); ?>"
          , data: { id: id }
        }).then(function(res){
          let html = "";
          if(res && res.length > 0)
          {
            html = res.map(x => `<option value='${x.id}'>${x.month}</option>`)
          }
          
        });
      }

       });
      </script>
    </body>
    </html>