<html>
  <head>
      <title>Creater</title>
      <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap.css" /> -->
      <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" />
      <!-- <link rel="stylesheet" href="<?php //echo base_url(); ?>assets/css/dataTables.bootstrap.css" /> -->
      <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/dataTables.bootstrap5.min.css" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </head>
  <body>
   <a href='<?php echo base_url("user_controller/add"); ?>' class='btn btn-primary ' style="margin-left: 1800;">Add</a>
    <table id="tab" class="table table-bordered table-striped "></table>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.1.1.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.js"></script>
</body>
</html>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.6.0.min.js "></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js "></script>
	<script>
$(function(){
			let dt = $("#tab").DataTable({
				ajax: {
					url: "<?php echo base_url('user_controller/get_data'); ?>"
					, dataSrc: ""
				}
				, columns: [
				{ data: "id", title: "#" }
				, { data: "fullname", title: "Name" }
				, { data: "prof", title: "Des" }
				, { data: "address", title: "Qua" }
				, { data: "dob", title: "Gender" }
				, { data: "id", title: "Action", render: (d) => `
				<a href='<?php echo base_url("user_controller/get_profile"); ?>/${d}' class='btn btn-primary lnk-edit' data-id='${d}'>View</a>
				` }
				]
			});

        $("#tab").on("click", ".lnk-view", function(e){
        let id = e.currentTarget.dataset.id;
        $.post({
          dataType:'json',
          url: "<?php echo base_url('user_controller/get_profile'); ?>"
          , data: { id: id }
        }).then(function(res){
                      console.log(res);
          if(res && res.fullname != undefined){
            $("#fullname").val(res.fullname);
            $("#id").val(res.id);
          } else {
            alert(res);
          }
        });
      });
		});
	</script>