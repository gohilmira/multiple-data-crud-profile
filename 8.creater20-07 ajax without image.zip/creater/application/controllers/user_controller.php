<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class user_controller extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('user_model');
		$this->load->helper('url');
	}
	public function index()
	{
		$this->load->view('list');
	}
	public function get_data()
	{
		echo json_encode($this->db->query("select * from user")->result());
	}
	public function get_profile($id)
	{
		$result=$this->db->query("select * from user where id='".$id."'")->row();
		$data['user'] = $result;
		$this->load->view('profile',$data);
	}
	public function add()
	{
		$this->load->view('add');
	}
	public function get_country()
    {
        
		$result['data']=$this->db->query("select * from country")->result();
		$this->load->view('add',$result);
		
    }
    public function get_month()
    {
        
		echo json_encode($this->db->query("select * from country")->result());
		
		
    }	
	public function save()
	{ 	
		$fullname=$this->input->post('fullname');
		$day=$this->input->post('day');
		$month=$this->input->post('month');
		$year=$this->input->post('year');
		$dob="$year-$month-$day";
		$prof=$this->input->post('prof');
		$bio=$this->input->post('bio');
		$platform_title=$this->input->post('platform_title');
		$pl_des=$this->input->post('pl_des');
		$country=$this->input->post('country');
		$address=$this->input->post('address');
		$location=$this->input->post('location');
		$phone=$this->input->post('phone');
		$email=$this->input->post('email');
		$website=$this->input->post('website');
		$facebook=$this->input->post('facebook');
		$linkedin=$this->input->post('linkedin');
		$twitter=$this->input->post('twitter');
		$github=$this->input->post('github');
		$php=$this->input->post('php');
		$wordpress=$this->input->post('wordpress');
		$javascript=$this->input->post('javascript');
		$jquery=$this->input->post('jquery');
		$collagename=$this->input->post('collagename');
		$e_s_month=$this->input->post('e_s_month');
		$e_s_year=$this->input->post('e_s_year');
		$e_e_month=$this->input->post('e_e_month');
		$e_e_year=$this->input->post('e_e_year');
		$edu_dec=$this->input->post('edu_dec');
		$com_name=$this->input->post('com_name');
		$job_title=$this->input->post('job_title');
		$w_location=$this->input->post('w_location');
		$w_s_month=$this->input->post('w_s_month');
		$w_s_year=$this->input->post('w_s_year');
		$w_e_month=$this->input->post('w_e_month');
		$w_e_year=$this->input->post('w_e_year');
		$work_dec=$this->input->post('work_dec');
		$id=$this->input->post('id');
		if ($id !="" && ((int)$id) >0)  
		{
			echo json_encode($this->db->query("update reg set  fullname=?, dob=?, prof=?, bio=?, platform_title=?, pl_des=?, country=?, address=?, location=?, phone=?, email=?, website=?, facebook=?, linkedin=?, twitter=?, github=?, php=?, wordpress=?, javascript=?, jquery=?, collagename=?, c_starting_date=?, c_ending_date=?, edu_dec=?, com_name=?, job_title=?, w_location=?, w_starting_date=?, w_ending_date=?, edu_dec=? where id =? ",[$fullname ,$dob ,$prof ,$bio ,$platform_title ,$pl_des ,$country ,$address ,$location ,$phone ,$email ,$website ,$facebook ,$linkedin ,$twitter ,$github ,$php ,$wordpress ,$javascript ,$jquery ,$collagename ,$c_starting_date ,$c_ending_date ,$edu_dec ,$com_name ,$job_title ,$w_location ,$w_starting_date ,$w_ending_date ,$edu_dec, $id]) >0);
		}else{
			
			$var1 = $this->db->query("insert into user (fullname, dob, prof, bio, country, address, location, phone, email, website, facebook, linkedin, twitter, github)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[$fullname, $dob, $prof, $bio, $country, $address, $location, $phone, $email, $website, $facebook, $linkedin, $twitter, $github ]) >0;

			if ($var1 == true) 
			{	
				$id= $this->db->insert_id();
				//echo $id;
				$insertarr = array();
				    for($i=0; $i<count($this->input->post('platform_title')); $i++){  
				        $insertarr = array(
				            'platform_title' => $this->input->post("platform_title")[$i],
				            'pl_des'  => $this->input->post("pl_des")[$i],
				            'user_id' => $id
				        ); 
				        $this->db->insert('work_platform', $insertarr); 
				    }
				   
				//$var2 = $this->db->query("insert into work_platform (platform_title, pl_des, user_id)values(?,?,?)",[$platform_title ,$pl_des,$id]) >0;
				    $skill = array();
				    for($i=0; $i<count((array)$this->input->post('skillname')); $i++){  
			        $skill = array(
			            'skillname' => $this->input->post("skillname")[$i],
			            'percentage' => $this->input->post("percentage")[$i],
			            'user_id' => $id
			        ); 
			        $this->db->insert('skill', $skill); 
				    }
				//$var3 = $this->db->query("insert into skill (php, wordpress, javascript, jquery,user_id)values($php, $wordpress, $javascript, $jquery, $id)") >0;
					$insertarr1 = array();
				    for($i=0; $i<count((array)$this->input->post('collagename')); $i++){  
				        $insertarr1 = array(
				            'collagename' => $this->input->post("collagename")[$i],
				            'e_s_month'  => $this->input->post("e_s_month")[$i],
				            'e_s_year'  => $this->input->post("e_s_year")[$i],
				            'e_e_month'  => $this->input->post("e_e_month")[$i],
				            'e_e_year'  => $this->input->post("e_e_year")[$i],
				            'edu_dec'  => $this->input->post("edu_dec")[$i],
				            'user_id' => $id
				        ); 
				        $this->db->insert('education', $insertarr1); 
				    }
				//$var4 = $this->db->query("insert into education (collagename, c_starting_date, c_ending_date, edu_dec,user_id)values(?,?,?,?,?)",[ $collagename, $c_starting_date, $c_ending_date, $edu_dec,$id]) >0;
				 $insertarr2 = array();
				    for($i=0; $i<count((array)$this->input->post('com_name')); $i++){  
				        $insertarr2 = array(
				            'com_name' => $this->input->post("com_name")[$i],
				            'job_title' => $this->input->post("job_title")[$i],
				            'w_location' => $this->input->post("w_location")[$i],
				            'w_s_month'  => $this->input->post("w_s_month")[$i],
				            'w_s_year'  => $this->input->post("w_s_year")[$i],
				            'w_e_month'  => $this->input->post("w_e_month")[$i],
				            'w_e_year'  => $this->input->post("w_e_year")[$i],
				            'work_dec'  => $this->input->post("work_dec")[$i],
				            'user_id' => $id
				        ); 
				        $this->db->insert('work_exp', $insertarr2); 
				    }   
				//$var5 = $this->db->query("insert into work_exp (com_name, job_title, w_location, w_starting_date, w_ending_date,work_dec,user_id)values(?,?,?,?,?,?,?)",[$com_name, $job_title, $w_location, $w_starting_date, $w_ending_date,$work_dec,$id]) >0;
			}else{
				echo("error");
			}
			echo json_encode($var1);
		}
	}
}



